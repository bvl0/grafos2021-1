1- make
2- ./grafos1 <path do arquivo>

Arquivos de teste dentro da pasta data e saida em data/out.

Exemplo de path:
./data/grafo_10_19.txt